package com.cg.capstore.UpdateDeliveryStatus.service;

public interface IUpdateDeliveryStatusService {
	public boolean orderStatus(int orderId, String orderStatus);
}
