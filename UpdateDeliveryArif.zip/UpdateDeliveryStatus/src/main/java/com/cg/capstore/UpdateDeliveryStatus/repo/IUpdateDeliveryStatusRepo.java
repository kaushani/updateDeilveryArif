package com.cg.capstore.UpdateDeliveryStatus.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.UpdateDeliveryStatus.entities.OrderDetails;

public interface IUpdateDeliveryStatusRepo extends JpaRepository<OrderDetails, Integer>{

}
