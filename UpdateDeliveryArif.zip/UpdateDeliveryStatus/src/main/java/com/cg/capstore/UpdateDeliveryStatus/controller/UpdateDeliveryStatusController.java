package com.cg.capstore.UpdateDeliveryStatus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.UpdateDeliveryStatus.service.IUpdateDeliveryStatusService;

@RestController
public class UpdateDeliveryStatusController {
@Autowired
IUpdateDeliveryStatusService IUpdateDeliveryStatusServiceObj;

public IUpdateDeliveryStatusService getIUpdateDeliveryStatusServiceObj() {
	return IUpdateDeliveryStatusServiceObj;
}

public void setIUpdateDeliveryStatusServiceObj(IUpdateDeliveryStatusService iUpdateDeliveryStatusServiceObj) {
	IUpdateDeliveryStatusServiceObj = iUpdateDeliveryStatusServiceObj;
}
@PutMapping("/update/{orderId}/{orderStatus}")
public boolean updateDeliveryStatus(@PathVariable("orderId") int orderId, @PathVariable("orderStatus") String orderStatus) {
	return IUpdateDeliveryStatusServiceObj.orderStatus(orderId, orderStatus);
	
}
}